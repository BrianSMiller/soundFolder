function timeStamp = filenameToTimeStamp(fileName,timeStampFormat)
%timeStamp = readTimeStamp(fileName,timeStampFormat)
% This function scans the wav filename for a timestamp to determine the
% starting date and time of the file. Embedding timestamps in the filename
% is a common feature of bioacoustics software such as PAMGuard, Ishmael,
% Raven, etc.
% FILENAME - A string containing the name to the wav file (e.g. output from DIR)
% TIMESTAMPFORMAT - A string compatible with Matlab DATESTR FORMATOUT, 
% for example, 'yyyy-mm-dd_HH-MM-SS'
% This function is part of the soundFolder package.
% See also: wavFolderInfo, audioread, readTimeStamp

% Swap the year, month, etc for individual digits
expression = regexprep(timeStampFormat,'dd','\\d\\d');
expression = regexprep(expression,'yyyy','\\d\\d\\d\\d');
expression = regexprep(expression,'mm','\\d\\d');
expression = regexprep(expression,'HH','\\d\\d');
expression = regexprep(expression,'MM','\\d\\d');
expression = regexprep(expression,'SS','\\d\\d');
expression = regexprep(expression,'fff','\\d\\d\\d');

% Now match the string
str = regexp(fileName,expression,'match');
if isempty(str)
    % No date could be extracted from filename    
    timeStamp = datenum([0 1 1 0 0 0]);
    error('File start timestamp could not be read from header. Using default timestamp of %s',datestr(timeStamp));
    keyboard;
else
    timeStamp = datenum(str,timeStampFormat);
end  